CriderGPT Helper is your AI farmhand for Farming Simulator 22.  

Features:  
- Fuel monitoring with HUD alerts  
- Auto-feed system for animals (auto top-up or notifications)  
- Precision Farming support: pH and nitrogen recommendations with cost estimates  
- Console compatible (Xbox/PlayStation)  

No store purchase needed — script runs in the background once activated.  
